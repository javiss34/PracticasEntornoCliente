"use strict";

//Ejercicio1
import { mostrarMes } from "./ejercicio1.js";
mostrarMes(6);

//ejercicio2
import { analisisNumerico } from "./ejercicio2.js";
analisisNumerico(3);

//ejercicio3
import { multiplosTres } from "./ejercicio3.js";
multiplosTres(20);

//ejercicio4
import { potencia } from "./ejercicio4.js";
potencia(2,2);

//ejercicio5
import { calcularMedia } from "./ejercicio5.js";
calcularMedia(10,20,30);

//ejercicio6
import { calculadora } from "./ejercicio6.js";
calculadora(5,5,"/");